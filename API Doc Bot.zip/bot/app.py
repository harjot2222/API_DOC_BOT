from flask import Flask, render_template, request, jsonify
import requests
from bs4 import BeautifulSoup
import google.generativeai as genai
from urllib.parse import urlparse, urljoin

app = Flask(__name__)

# Global variable to store the API key (for simplicity; use Flask-Session in production)
api_key = None

# Route to handle API key submission
@app.route('/set_api_key', methods=['POST'])
def set_api_key():
    global api_key
    api_key = request.form.get('api_key')
    if not api_key:
        return jsonify({'error': 'Please enter a valid Gemini API key.'}), 400
    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel('gemini-1.5-flash')
        return jsonify({'message': 'API key set successfully!'})
    except Exception as e:
        return jsonify({'error': f'Invalid API key: {str(e)}'}), 400

# Function to find API base URL from a general website
def find_api_base_url(website_url):
    if not api_key:
        return "Please set your Gemini API key first."
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(website_url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')

        for link in soup.find_all(['a', 'link', 'script'], href=True):
            href = link['href']
            if ('api.' in href or '/api' in href.lower()) and 'googleapis' not in href.lower():
                full_url = href if href.startswith('http') else urljoin(website_url, href)
                parsed = urlparse(full_url)
                base_url = f"{parsed.scheme}://{parsed.netloc}"
                if 'api' in parsed.path.lower():
                    path_parts = parsed.path.split('/')
                    api_index = [i for i, part in enumerate(path_parts) if 'api' in part.lower()][0]
                    base_url = f"{base_url}{'/'.join(path_parts[:api_index + 1])}"
                return base_url

        prompt = f"""
        Given the website {website_url}, suggest its API base URL. For example:
        - If the website is 'https://openweathermap.org', the API base URL should be 'https://api.openweathermap.org'.
        - If the website is 'https://github.com', the API base URL should be 'https://api.github.com'.
        Do not suggest unrelated URLs like Google Fonts (e.g., 'https://fonts.googleapis.com'). Return only the URL.
        """
        response = genai.GenerativeModel('gemini-1.5-flash').generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Error finding API URL: {str(e)}"

# Function to fetch APIs from an API base URL
def fetch_apis_from_url(api_url):
    if not api_key:
        return ["Please set your Gemini API key first."]
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(api_url, headers=headers, timeout=10)
        response.raise_for_status()
        content_type = response.headers.get('Content-Type', '').lower()

        api_links = []
        if 'json' in content_type:
            data = response.json()
            if isinstance(data, dict):
                api_links = [f"{api_url.rstrip('/')}/{key}" for key in data.keys() if key.startswith('/')]
            elif isinstance(data, list):
                api_links = [f"{api_url.rstrip('/')}/{item}" for item in data if isinstance(item, str) and item.startswith('/')]
        elif 'html' in content_type or 'text' in content_type:
            soup = BeautifulSoup(response.text, 'html.parser')
            for link in soup.find_all('a', href=True):
                href = link['href']
                if 'api' in href.lower() or 'endpoint' in href.lower():
                    api_links.append(urljoin(api_url, href))

        if not api_links:
            prompt = f"Suggest 3 plausible API endpoints for the base URL {api_url} (e.g., '/data', '/users'). Return as a list."
            response = genai.GenerativeModel('gemini-1.5-flash').generate_content(prompt)
            api_links = [urljoin(api_url, endpoint.strip()) for endpoint in response.text.split('\n') if endpoint.strip()]

        return api_links if api_links else ["No APIs found"]
    except Exception as e:
        return [f"Error fetching APIs: {str(e)}. Please ensure the API base URL is correct (e.g., 'https://api.openweathermap.org' for OpenWeatherMap)."]

# Function to generate simplified, structured API documentation
def generate_api_doc(api_url):
    if not api_key:
        return "Please set your Gemini API key first."
    prompt = f"""
    Explain the API endpoint '{api_url}' in a very simple, beginner-friendly way. Assume it's a REST API unless specified otherwise.  
    Format the response in Markdown with the following structure, ensuring proper spacing, indentation, and readability:

    ⭐ {api_url} ⭐

    👉 What Does This API Do? 
    Provide a short, clear description (2-3 sentences) of what this API endpoint does. Use very simple language that a beginner can understand.

    👉 How Can I Use It?
    List 4-5 practical use cases in bullet points. Keep each use case short and easy to understand.  
    - Use case 1: A brief description.  
    - Use case 2: A brief description.  
    - Use case 3: A brief description. 
    - Use case 4: A brief description. 
    - Use case 5: A brief description.  

    👉 How Do I Call This API? 
    Show a simple HTTP request example in a code block. Include necessary parameters (make assumptions if needed). Use simple parameter names and values.  
    ```bash
    GET {api_url}?param1=value1&param2=value2
    ```  

    👉 Authentication  
    Does it require an API key or token? If yes, explain how to include it in the request.

    👉 Endpoint & Method  
    - **URL:** '{api_url}' 
    - **Method:** 'GET/POST/PUT/DELETE' 

    👉 Parameters  
    List required and optional parameters with explanations in a well-structured Markdown grid table. 
    Use the exact format below, ensuring proper alignment with spaces and pipes (|):
    | Parameter  | Type    | Required? | Description  |
    |------------|---------|-----------|--------------|
    | 'param1'   | string  | ✅ Yes    | What it does |
    | 'param2'   | int     | ❌ No     | What it does |

    
    👉 What Will I Get Back?
    Show a simple JSON response example in a code block. Use a small, easy-to-understand data structure (2-3 key-value pairs).  
    ```json
    {{
        "key1": "value1",
        "key2": "value2"
    }}
    ```  

    👉 Good to Know 
    List 3-4 important notes in bullet points. Include things like whether an API key is needed, possible errors, or tips for beginners.  
    - Note 1: A brief tip or requirement.  
    - Note 2: Another tip or requirement.
    - Note 3: Another tip or requirement.

     Rules for Formatting: 
    - Use simple, beginner-friendly language (avoid technical jargon).  
    - Add a blank line between each section for proper spacing.  
    - Use bullet points for lists (e.g., use cases, notes).  
    - Bold the section headings (e.g., What Does This API Do?).  
    - Ensure code blocks are properly formatted with triple backticks (```).  
    - Keep the tone friendly and encouraging for beginners.  
    """
    response = genai.GenerativeModel('gemini-1.5-flash').generate_content(prompt)
    return response.text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/find_api_url', methods=['POST'])
def find_api_url():
    if not api_key:
        return jsonify({'error': 'Please set your Gemini API key first.'}), 400
    website_url = request.form['website_url']
    api_base_url = find_api_base_url(website_url)
    return jsonify({'api_base_url': api_base_url})

@app.route('/fetch_apis', methods=['POST'])
def fetch_apis():
    if not api_key:
        return jsonify({'error': 'Please set your Gemini API key first.'}), 400
    api_url = request.form['api_url']
    apis = fetch_apis_from_url(api_url)
    return jsonify({'apis': apis})

@app.route('/get_doc', methods=['POST'])
def get_doc():
    if not api_key:
        return jsonify({'error': 'Please set your Gemini API key first.'}), 400
    api_url = request.form['api_url']
    doc = generate_api_doc(api_url)
    return jsonify({'doc': doc})

@app.route('/chat', methods=['POST'])
def chat():
    if not api_key:
        return jsonify({'error': 'Please set your Gemini API key first.'}), 400
    user_input = request.form['message']
    if "api" not in user_input.lower() and "documentation" not in user_input.lower():
        return jsonify({'response': "This prompt is out of scope. I focus on API documentation queries!"})
    prompt = f"Answer this API documentation-related query in a simple way: {user_input}"
    response = genai.GenerativeModel('gemini-1.5-flash').generate_content(prompt, generation_config={"max_output_tokens": 200})
    return jsonify({'response': response.text})

if __name__ == '__main__':
    app.run(debug=True)
